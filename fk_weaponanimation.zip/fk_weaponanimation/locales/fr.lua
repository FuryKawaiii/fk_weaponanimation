Locales['fr'] = {
    ['mainMenu_title'] = 'Animation d\'armes',
    ['mainMenu_subtitle'] = 'Intéraction',
    ['mainMenu_separator'] = '~r~↓~s~ Menu Animations ~r~↓~s~',
}